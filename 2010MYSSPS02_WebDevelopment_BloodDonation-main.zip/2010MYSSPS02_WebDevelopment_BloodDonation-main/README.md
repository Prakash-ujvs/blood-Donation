# Blood Donation

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/936da81c6582422993b9f7cd663f7644)](https://app.codacy.com/gh/99002778/2010MYSSPS02_WebDevelopment_BloodDonation?utm_source=github.com&utm_medium=referral&utm_content=99002778/2010MYSSPS02_WebDevelopment_BloodDonation&utm_campaign=Badge_Grade)

![Scala CI](https://github.com/99002778/2010MYSSPS02_WebDevelopment_BloodDonation/workflows/Scala%20CI/badge.svg)
![CI](https://github.com/99002778/2010MYSSPS02_WebDevelopment_BloodDonation/workflows/CI/badge.svg)
![Jekyll site CI](https://github.com/99002778/2010MYSSPS02_WebDevelopment_BloodDonation/workflows/Jekyll%20site%20CI/badge.svg)

Blood donation is required during an organ transplant, accidents, cancer treatment etc. For blood donation, one needs to check for a donation camp or needs to visit blood bank.. This system maintains the list of blood donors and helps the recipients to track and search the right donor easily.
